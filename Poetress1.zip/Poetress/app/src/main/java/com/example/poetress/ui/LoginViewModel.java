package com.example.poetress.ui;

import androidx.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
}
