package com.example.poetress.ui.profile.Settings;

import androidx.lifecycle.ViewModel;

public class SettingsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
