package com.example.poetress.ui;
import androidx.lifecycle.ViewModel;

public class RegisterViewModel extends ViewModel {
}
