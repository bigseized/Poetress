package com.example.poetress.ui.createFragment;

import androidx.lifecycle.ViewModel;

public class CreateMainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
