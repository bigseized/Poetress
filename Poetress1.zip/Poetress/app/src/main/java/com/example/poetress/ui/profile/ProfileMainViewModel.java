package com.example.poetress.ui.profile;

import androidx.lifecycle.ViewModel;

public class ProfileMainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
