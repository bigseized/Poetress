package com.example.poetress.ui;

import androidx.lifecycle.ViewModel;

public class FeedMainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
