package com.example.poetress.ui.swiper;

import androidx.lifecycle.ViewModel;

public class SwiperMainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
