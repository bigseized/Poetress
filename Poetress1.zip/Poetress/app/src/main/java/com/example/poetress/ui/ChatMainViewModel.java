package com.example.poetress.ui;

import androidx.lifecycle.ViewModel;

public class ChatMainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}